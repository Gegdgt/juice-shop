# Requisitos de seguridad y casos de abuso (Dado / Cuando / Entonces)

Los requisitos siguientes son **objetivos verificables propuestos**. La aplicación de laboratorio es deliberadamente vulnerable, de modo que es esperable que algunos fallen antes de la remediación. No describirlos como controles ya implementados.

## Requisitos medibles
| ID | Requisito de diseño | Verificación futura esperada |
|---|---|---|
| RS-01 | Limitar intentos fallidos de autenticación por cuenta/IP | Desde un laboratorio autorizado, tras 5 fallos en 15 min el siguiente intento recibe limitación (p. ej., HTTP 429), sin revelar si la cuenta existe; confirmar el umbral elegido con el equipo |
| RS-02 | Comprobar identidad y titularidad en cada recurso de usuario | La lectura/modificación de un recurso ajeno devuelve 403 o 404 y no expone datos |
| RS-03 | Parametrizar consultas y validar entradas al consultar datos | Una cadena de prueba no altera la lógica de consulta ni produce divulgación o error SQL crudo |
| RS-04 | Codificar salida de texto de usuario y aplicar política de contenido adecuada | El texto aportado se representa como texto, sin ejecutar JavaScript |
| RS-05 | Detectar y limitar ráfagas de peticiones | El umbral configurado (a definir para el laboratorio) provoca alerta/limitación y no afecta solicitudes legítimas ordinarias |
| RS-06 | Registrar eventos de seguridad con hora, ruta, acción y resultado, sin secretos | Una acción de prueba produce evento recuperable con marcas temporales y sin contraseña/JWT/cookie |
| RS-07 | Calcular y verificar precios/totales del lado servidor | Manipular un monto en el navegador no cambia el total final aceptado |
| RS-08 | Mantener interfaces privadas no expuestas directamente al host ni Internet | `docker compose ps` muestra WAF en `127.0.0.1:8080`; el backend no tiene `ports` publicados |
| RS-09 | Autorizar operaciones administrativas por rol en backend | Usuario sin privilegios recibe 403/404 ante una acción de administración |
| RS-10 | Proteger secretos y sesiones en tránsito y repositorio | No hay secretos subidos a GitHub; en despliegues no locales se exige HTTPS y configuración segura de sesiones |

## Casos de abuso

### CA-01 — Fuerza bruta / abuso del inicio de sesión
**Dado** un actor no autenticado que intenta acceder a una cuenta de prueba, **cuando** realiza más intentos fallidos que el umbral aprobado, **entonces** la aplicación debe aplicar una limitación temporal, registrar el evento y no confirmar la existencia de la cuenta.  
**Amenazas:** T-01, T-05; **requisitos:** RS-01.  
**Evidencia esperada:** límite observable y log (posterior H3). Estado inicial: PENDIENTE.

### CA-02 — Acceso al carrito o pedido de otra cuenta (IDOR)
**Dado** dos cuentas ficticias A y B con recursos diferentes, **cuando** A solicita o intenta cambiar un recurso que pertenece a B, **entonces** el backend debe rechazar la operación con 403/404 y no revelar información de B.  
**Amenazas:** T-06, T-10; **requisito:** RS-02. Estado: PENDIENTE.

### CA-03 — Inyección SQL a través de un campo de búsqueda
**Dado** un usuario que controla un campo de entrada, **cuando** envía texto malformado o con caracteres especiales que pudiera alterar una consulta, **entonces** la API debe tratarlo como dato y no ejecutar consultas arbitrarias ni revelar errores internos.  
**Amenaza:** T-07; **requisito:** RS-03. Estado: PENDIENTE.

### CA-04 — XSS en entrada mostrada a otros usuarios
**Dado** un campo que recibe texto de una cuenta de prueba, **cuando** se presenta contenido con marcado activo, **entonces** la interfaz debe mostrarlo de forma segura sin ejecutar scripts.  
**Amenaza:** T-08; **requisito:** RS-04. Estado: PENDIENTE.

### CA-05 — Ráfaga de solicitudes contra un recurso
**Dado** un cliente de prueba que accede reiteradamente a una ruta local, **cuando** supera el umbral definido de peticiones en una ventana corta, **entonces** el servicio debe detectar/limitar el abuso y continuar respondiendo a uso normal.  
**Amenaza:** T-03; **requisito:** RS-05. Estado: PENDIENTE.

### CA-06 — Modificación de precio o total desde el cliente
**Dado** una orden de laboratorio con precios conocidos, **cuando** un usuario modifica los montos que envía el navegador, **entonces** el backend debe ignorar el precio cliente, recalcular el total y rechazar incoherencias.  
**Amenazas:** T-02, T-09; **requisito:** RS-07. Estado: PENDIENTE.

### CA-07 — Acción sospechosa sin trazabilidad, o logs con secretos
**Dado** un evento de seguridad en el entorno de prueba, **cuando** se procesa una solicitud sospechosa, **entonces** se debe registrar fecha/hora, origen, ruta y resultado, sin registrar contraseñas, tokens ni cookies completos.  
**Amenazas:** T-04, T-12, T-13; **requisito:** RS-06. Estado: PENDIENTE.

### CA-08 — Usuario normal que intenta una función administrativa
**Dado** una cuenta de prueba sin permisos de administrador, **cuando** intenta utilizar una función administrativa existente, **entonces** el servidor debe rechazar la acción y conservar el estado sin cambios.  
**Amenaza:** T-11; **requisito:** RS-09. Estado: PENDIENTE.

## Regla del H1
En el H1 se **redactan** los casos con resultados esperados, y se recopila la superficie de ataque. Las pruebas de explotación y los PoC reproducibles se exigen explícitamente en el **H2**. Registrar posteriormente qué casos no satisface la app y qué corrección los resuelve.
