# PASTA I — Objetivos y PASTA II — Alcance técnico

> Caso de estudio: tienda electrónica **de demostración** OWASP Juice Shop. Los objetivos de negocio son supuestos del ejercicio, no afirmaciones sobre operaciones comerciales reales.

## Etapa I: definición de objetivos de negocio

**Propósito funcional:** permitir que una persona consulte un catálogo, use una cuenta, cree una cesta y complete flujos de compra simulada.

| ID | Objetivo de negocio | Activo principal | Impacto si falla | Objetivo de seguridad asociado |
|---|---|---|---|---|
| ON-01 | Permitir consultas confiables al catálogo | Productos/precios | Medio: información de productos manipulada | Integridad del catálogo y precios |
| ON-02 | Proteger cuentas de usuarios de prueba | Credenciales/sesiones | Alto: acceso a datos y acciones de otra cuenta | Autenticación, sesión segura, control de acceso |
| ON-03 | Mantener separados pedidos y carritos | Pedidos/detalles de carrito | Alto: lectura o modificación entre usuarios | Autorización por recurso |
| ON-04 | Mantener disponibilidad razonable | Aplicación y API | Medio/alto: servicios inutilizables | Control de tasa, monitoreo |
| ON-05 | Poder reconstruir eventos sospechosos | Logs de WAF y app | Alto: pérdida de trazabilidad | Registro, integridad y protección de logs |

**Datos y clasificación:** credenciales y tokens (secretos); datos de cuenta y pedidos (sensibles del laboratorio); catálogo (público); logs (internos, potencialmente sensibles). Usar únicamente cuentas ficticias y datos de prueba.

**Requisitos generales de seguridad:** mínimos privilegios, autorización de servidor, validación de entradas, trazabilidad, privacidad de tokens y resiliencia básica. Requisitos medibles en `04-Requisitos-y-casos-de-abuso.md`.

**Restricción del ejercicio:** solo despliegue y pruebas locales autorizadas; nunca el Juice Shop público ni terceros.

## Etapa II: alcance técnico

| Capa / componente | Tecnología / ubicación | ¿Incluido? | Notas |
|---|---|---|---|
| Navegador y frontend | Angular SPA, ejecutada en navegador | Sí | Cliente fuera del límite confiable del backend |
| Proxy/WAF | ModSecurity + OWASP CRS, contenedor local | Sí | Recibe solicitudes en `127.0.0.1:8080`; comienza en `DetectionOnly` |
| Backend | Node.js / Express / REST, contenedor Juice Shop | Sí | Servicio `juice-shop:3000` accesible desde la red Docker; no se publica directamente en el host |
| Datos persistentes | SQLite alojada por el servidor | Sí | Motor/archivo bajo el control de la aplicación; validar acceso concreto contra código fuente |
| Control de versiones | Fork público de GitHub | Sí | Contiene código y documentos, no secretos ni evidencias privadas |
| SIEM / Filebeat / Kibana | Fase H3 | Futuro | Se dibuja como componente planificado, no como instalado en H1 |
| SAST / SCA / DAST / SBOM | Fase H2 | Futuro | No confundir requisitos deseados con controles que ya funcionan |
| Servicio público y universidad | Infraestructura de terceros | **No** | Fuera de alcance y prohibido hacer pruebas |

**Entorno esperado:** Windows con Docker Desktop (WSL 2) y `docker compose`.

**Supuestos por confirmar con observación local:** rutas exactas de la API; flujos de login; mecanismo de sesión; qué recursos usa la aplicación; qué eventos registra el WAF.

**Criterio de éxito del alcance:** navegador llega a la tienda **por el WAF** (`http://127.0.0.1:8080/`), sin puerto 3000 publicado por Docker; los contenedores aparecen activos en `docker compose ps`.
