# Kit de inicio — H1 Diseño Seguro / Juice Shop

Este kit se copia **dentro del fork local** de OWASP Juice Shop. No incluye la aplicación ni evidencia inventada.

## Antes de comenzar
1. Instalar Docker Desktop (Linux containers/WSL 2), Git y opcionalmente VS Code.
2. Crear **un fork público** de https://github.com/juice-shop/juice-shop y deshabilitar sus workflows originales desde GitHub > Actions (se hace por workflow).
3. Clonar el fork en Windows: `git clone https://github.com/TU_USUARIO/juice-shop.git` y entrar con `cd juice-shop`.
4. Copiar las carpetas `docs` y `entorno-blue-team` de este kit a la raíz del fork.
5. En PowerShell, desde la raíz del fork:

```powershell
docker compose -f .\entorno-blue-team\compose.yaml config
docker compose -f .\entorno-blue-team\compose.yaml up -d
docker compose -f .\entorno-blue-team\compose.yaml ps
```

Abrir **http://127.0.0.1:8080**. El WAF está configurado en **DetectionOnly** y el contenedor Juice Shop NO publica el puerto 3000 en el host.

## Trabajo de H1
- Completar `docs/hito-1/01-PASTA-1-2.md` (objetivos, alcance).
- Revisar `docs/hito-1/02-PASTA-3-DFD.md` y adaptar diagrama Mermaid a los flujos observados.
- Validar `docs/hito-1/03-PASTA-4-STRIDE.md`, incluyendo amenazas y controles por componente.
- Revisar `docs/hito-1/04-Requisitos-y-casos-de-abuso.md` (requisitos y ocho casos verificables).
- **Red Team:** seguir `docs/hito-1/05-RedTeam-reconocimiento.md` y registrar endpoints observados.
- **Blue Team:** seguir `docs/hito-1/06-BlueTeam-configuracion.md` y registrar estado del proxy.
- Guardar capturas con nombres sin datos sensibles en `docs/hito-1/evidencias/`.
- Completar `docs/hito-1/07-CHECKLIST.md` y subir al fork.

## Guardar cambios
```powershell
git status
git add docs/hito-1 entorno-blue-team
git commit -m "docs: completar H1 diseno seguro PASTA STRIDE reconocimiento"
git push origin HEAD
```

## Límites de seguridad
- Solo se permite reconocimiento y, en hitos posteriores, pruebas ofensivas contra **la instancia local autorizada** del equipo.
- No se debe escanear ni atacar el Juice Shop público, la Universidad ni sistemas de terceros.
- No usar usuarios/contraseñas reales. No subir cookies, JWT, API keys ni datos de terceros.
- La configuración de Docker se publica solo en loopback (`127.0.0.1`) y se usa para fines académicos, no producción.

## Referencias
- Consigna: «Proyecto Final Integrador — Juice Shop y el SSDLC», páginas 1-4.
- https://github.com/juice-shop/juice-shop
- https://pwning.owasp-juice.shop/companion-guide/latest/part1/running.html
- https://github.com/coreruleset/modsecurity-crs-docker
- https://docs.docker.com/desktop/setup/install/windows-install/
- https://community.owasp.org/Threat_Modeling_Process
