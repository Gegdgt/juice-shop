# Red Team — Reconocimiento autorizado y superficie de ataque

**Responsable:** integrante Red Team.  
**Objetivo de H1:** inventariar **sin explotación** las superficies accesibles y generar hipótesis STRIDE, con pasos reproducibles.  
**Único blanco autorizado:** `http://127.0.0.1:8080/` de la máquina que ejecuta el Docker Compose del grupo. **Prohibido** apuntar a Juice Shop público, UVG, IPs de terceros o servicios desconocidos.

## Paso 1. Confirmar destino y contenedores
Desde la raíz del fork, en PowerShell:

```powershell
docker compose -f .\entorno-blue-team\compose.yaml ps
curl.exe -I http://127.0.0.1:8080/
```

Documentar fecha/hora local, nombre del entorno, URL, código HTTP de respuesta y capturas (`evidencias/01-contenedores.png`, `02-entrada-waf.png`). Una respuesta inesperada requiere investigar; no inventar que funcionó.

## Paso 2. Exploración funcional con el navegador
1. Abrir `http://127.0.0.1:8080/`.
2. Navegar con datos ficticios por catálogo, búsqueda, registro, login, carrito, pedidos, feedback y opciones que **realmente aparezcan** en la versión instalada.
3. Abrir DevTools con **F12** > **Network** > **Fetch/XHR**. Si no hay peticiones, activar **All** y recargar.
4. Para cada acción, registrar: ruta observada, método HTTP, parámetros (sin secretos), si requiere sesión, qué datos devuelve y qué límite de confianza cruza.
5. Tomar capturas de la funcionalidad y de Network, ocultando contraseñas, cookies, JWT, datos de otros usuarios.

## Paso 3. Encabezados y recursos públicos (solo local)
```powershell
curl.exe -I http://127.0.0.1:8080/
curl.exe -i http://127.0.0.1:8080/robots.txt
```

Registrar si `robots.txt` existe o responde 404; ambas son observaciones válidas. Revisar las respuestas HTTP, los recursos públicos descargados por el navegador y los mensajes de error. No ejecutar escaneos masivos para el H1.

## Paso 4. Determinar superficie de ataque
Clasificar observaciones en:
- **Identidad/sesiones:** registro, login, logout, recuperación, áreas que requieren autenticación.
- **Entradas de usuario:** búsqueda, formularios, parámetros, comentarios/feedback si existen.
- **Recursos por identificador:** perfiles, carritos y pedidos, cuando existan en la versión.
- **Archivos/recursos estáticos:** rutas accesibles y controles si existen.
- **Operaciones privilegiadas:** funciones administrativas que aparezcan en el laboratorio.
- **Fronteras:** navegador→WAF, WAF→API, API→DB.

## Paso 5. Registrar hallazgos observacionales
| ID | Página/función | Método y ruta **observados** | ¿Requiere login? | Datos recibidos/enviados | Hipótesis STRIDE | Evidencia |
|---|---|---|---|---|---|---|
| REC-01 | [Completar] | [PENDIENTE] | [PENDIENTE] | [Sin secretos] | [S/T/R/I/D/E] | [captura] |
| REC-02 | [Completar] | [PENDIENTE] | [PENDIENTE] | [Sin secretos] | [S/T/R/I/D/E] | [captura] |
| REC-03 | [Completar] | [PENDIENTE] | [PENDIENTE] | [Sin secretos] | [S/T/R/I/D/E] | [captura] |
| REC-04 | [Completar] | [PENDIENTE] | [PENDIENTE] | [Sin secretos] | [S/T/R/I/D/E] | [captura] |
| REC-05 | [Completar] | [PENDIENTE] | [PENDIENTE] | [Sin secretos] | [S/T/R/I/D/E] | [captura] |

## Paso 6. Transferencia al Blue Team
Por cada hipótesis indicar `T-xx` de `03-PASTA-4-STRIDE.md`, control `RS-xx`, prioridad y dato adicional por validar. No etiquetar una amenaza probable como vulnerabilidad confirmada sin prueba y evidencia.

## Resumen de reconocimiento (a completar)
**Fecha/hora:** [PENDIENTE]  
**Entorno autorizado:** http://127.0.0.1:8080/  
**Versión o commit inspeccionado:** [PENDIENTE]  
**Funciones recorridas:** [PENDIENTE]  
**Rutas únicas documentadas:** [PENDIENTE]  
**Principales superficies:** [PENDIENTE]  
**Hipótesis priorizadas:** [PENDIENTE]  
**Evidencia visual registrada:** [PENDIENTE]
