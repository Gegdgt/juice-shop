# PASTA III — Descomposición, DFD y límites de confianza

## Actores y activos
- **Actor externo A1:** usuario anónimo o autenticado (cuenta de prueba) en navegador local.
- **Proceso P1:** WAF ModSecurity + OWASP CRS (proxy inverso).
- **Proceso P2:** servidor Node.js/Express de Juice Shop; entrega Angular SPA y gestiona API REST.
- **Almacén D1:** SQLite, almacenamiento de la aplicación (no un servidor separado).
- **Almacén D2 (futuro H3):** plataforma de logs/Elastic; NO es requisito que esté activa en H1.

## DFD — flujos de datos y zonas de confianza

```mermaid
flowchart LR
  subgraph TB1["TB-01 · Cliente no confiable"]
    U["A1 · Navegador / Angular SPA"]
  end
  subgraph TB2["TB-02 · Docker local / servicios"]
    W["P1 · WAF ModSecurity + CRS<br/>localhost:8080"]
    A["P2 · Juice Shop Node.js + Express<br/>REST API + SPA"]
    subgraph TB3["TB-03 · Persistencia (acceso solo desde backend)"]
      D[("D1 · SQLite")]
    end
  end
  L[("D2 · SIEM / Elastic<br/>Planificado para H3")]
  U -->|"F01 · GET/POST + datos de sesión"| W
  W -->|"F02 · solicitud inspeccionada"| A
  A -->|"F03 · consultas y cambios"| D
  D -->|"F04 · resultados / registros"| A
  A -->|"F05 · HTML/JS y respuestas JSON"| W
  W -->|"F06 · respuesta HTTP"| U
  W -.->|"F07 · eventos WAF; integración futura"| L
```

**Nota de diseño:** la SPA Angular se ejecuta **en el navegador**. No es otro servicio desplegado detrás del WAF. Los datos de sesión, controles de autorización y credenciales deben validarse por el servidor.

**Nota de límites de confianza:**
- **LC-01 Cliente ↔ WAF:** nunca confiar en parámetros, cabeceras, formularios ni tokens enviados por el navegador.
- **LC-02 WAF ↔ API:** el WAF filtra/observa, pero el backend sigue teniendo que validar identidad, permisos y entradas; un WAF no sustituye estas comprobaciones.
- **LC-03 API ↔ base de datos:** las consultas y cambios deben estar controlados por la aplicación; SQLite no se publica a la red.
- **LC-04 WAF ↔ SIEM (futuro):** los logs deben conservar integridad y excluir secretos. Añadir y actualizar DFD al llegar a H3.

## Tabla de flujos a validar
| Flujo | Origen → destino | Tipo de información | Protección / amenaza | Estado |
|---|---|---|---|---|
| F01 | Navegador → WAF | URL, parámetros, cabeceras, cuerpos de petición | Amenazas de entrada, spoofing | Diseño; por comprobar |
| F02 | WAF → API | Tráfico HTTP inspeccionado | Bypass, manipulación, denegación de servicio | Diseño; por comprobar |
| F03 | API → SQLite | Consultas/actualizaciones de usuario y pedido | SQLi, IDOR indirecto, tampering | Diseño; por comprobar |
| F04 | SQLite → API | Filas y datos de aplicación | Divulgación no autorizada | Diseño; por comprobar |
| F05 | API → WAF | HTML/JS/JSON | Filtración y XSS en cliente | Diseño; por comprobar |
| F06 | WAF → navegador | Respuesta HTTP | Exposición de datos | Diseño; por comprobar |
| F07 | WAF → SIEM | Logs de seguridad | Repudio, pérdida de eventos | Futuro H3 |

## Figura de referencia exportada

![DFD de referencia](DFD-referencia.png)

El archivo `DFD-referencia.dot` permite modificar el diagrama con Graphviz. Los formatos SVG y PNG son exportables, pero representan la arquitectura **prevista**, no una captura del sistema ejecutándose.

## Cómo convertir esto en una figura para el informe
1. Abrir https://mermaid.live/ y pegar el bloque `mermaid`, o usar la vista previa de Mermaid de GitHub.
2. Exportar PNG/SVG del diagrama; guardar en `docs/hito-1/evidencias/DFD.png`.
3. Si el docente exige formas DFD clásicas, recrearlo en https://app.diagrams.net/: rectángulo = entidad, círculo/proceso = proceso, cilindro = almacenamiento, línea discontinuada = límite de confianza.
4. Contrastar los flujos con DevTools (Network) y con el código fuente; dejar visibles los límites LC-01/LC-02/LC-03.
