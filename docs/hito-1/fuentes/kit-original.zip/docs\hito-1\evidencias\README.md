# Evidencias visuales

Guardar aquí capturas propias del laboratorio. No se incluyen capturas inventadas.

| Nombre sugerido | Qué demuestra | Responsable | Estado |
|---|---|---|---|
| `01-contenedores.png` | Contenedores activos, nombre de servicios y puertos publicados | Blue | Pendiente |
| `02-entrada-waf.png` | Página Juice Shop cargada desde `http://127.0.0.1:8080/` | Ambos | Pendiente |
| `03-network-publico.png` | DevTools Network con rutas sin secretos | Red | Pendiente |
| `04-network-login.png` | Solicitud de login con credenciales/tokens ocultos | Red | Pendiente |
| `05-dfd.png` | Diagrama de flujos y límites de confianza | Ambos | Pendiente |
| `06-waf-config.png` | DetectionOnly, BACKEND, puerto | Blue | Pendiente |

Anotar en el informe fecha/hora local y método de recolección. Borrar u ocultar datos sensibles antes de guardar y hacer commit. No subir logs crudos ni archivos de sesión.
