# Checklist de entrega H1

## Configuración
- [ ] Grupo / roles y repositorio público documentados. La consigna indica cuatro integrantes (2 Red, 2 Blue).
- [ ] Fork creado y workflows originales deshabilitados.
- [ ] Entorno Docker Compose activo y visitable **a través del WAF** en `http://127.0.0.1:8080/`.
- [ ] El backend no está publicado directamente al host.

## Diseño seguro (PASTA I-IV)
- [ ] Objetivos de negocio y activos claros con impacto si falla.
- [ ] Alcance técnico explícito, tecnologías, roles y límites de alcance.
- [ ] DFD completo y consistente con arquitectura real: entidades, procesos, datos, flujos, límites de confianza.
- [ ] Cada límite de confianza está explicado.
- [ ] Tabla STRIDE con amenazas vinculadas a **componentes o flujos**, consecuencias y mitigaciones.
- [ ] Requisitos numerados, observables, medibles.
- [ ] Al menos cinco casos Dado / Cuando / Entonces, asociados a requisitos y amenazas.

## Red Team
- [ ] Único destino local autorizado documentado.
- [ ] Evidencia de navegación y al menos cinco entradas/rutas **realmente observadas** (si la app expone suficientes).
- [ ] Superficies identificadas y vinculadas con amenazas del DFD.
- [ ] No se afirma que una vulnerabilidad esté explotada si no se comprobó.

## Evidencias y entrega
- [ ] Capturas y tablas con fechas, metodología y resultados, sin secretos.
- [ ] Documentación guardada en `docs/hito-1` del fork y cambios subidos (`git push`).
- [ ] Si se usó IA en la entrega, se citó conforme a la guía UVG.
- [ ] Revisión final Red+Blue de consistencia: `T-xx` ↔ `RS-xx` ↔ `CA-xx`.

## Comandos de verificación y entrega
```powershell
docker compose -f .\entorno-blue-team\compose.yaml config
docker compose -f .\entorno-blue-team\compose.yaml ps
git status
git add docs/hito-1 entorno-blue-team
git commit -m "docs: H1 PASTA STRIDE DFD reconocimiento"
git push origin HEAD
```
