# H1 — Diseño Seguro: OWASP Juice Shop

**Curso:** Desarrollo Seguro — UVG 2026  
**Alcance:** PASTA etapas 1–4, STRIDE, requisitos, casos de abuso y reconocimiento Red Team.  
**Estado:** borrador inicial; marcar evidencia como observada solo después de verificarla localmente.

## Roles
| Rol | Responsable | Función en H1 |
|---|---|---|
| Red Team | Integrante Red Team (completar nombre) | Reconocimiento, inventario de superficie de ataque, hipótesis de amenazas y evidencias. |
| Blue Team | Sebas Juárez | Revisión de arquitectura, límites de confianza, medidas preventivas, configuración WAF y evidencias. |
| Integrantes adicionales | Por confirmar | La consigna pide grupos de cuatro: dos Red y dos Blue. |

## Índice de evidencia
1. [PASTA 1 y 2: objetivos / alcance](01-PASTA-1-2.md)
2. [PASTA 3: DFD y límites de confianza](02-PASTA-3-DFD.md)
3. [PASTA 4: STRIDE por componente](03-PASTA-4-STRIDE.md)
4. [Requisitos y casos de abuso](04-Requisitos-y-casos-de-abuso.md)
5. [Red Team: reconocimiento](05-RedTeam-reconocimiento.md)
6. [Blue Team: configuración](06-BlueTeam-configuracion.md)
7. [Lista de comprobación final](07-CHECKLIST.md)
8. [Capturas](evidencias/README.md)

**Ambiente probado:** [PENDIENTE: fecha, Windows, Docker, versión app si está disponible, commit de fork]  
**URL autorizada:** `http://127.0.0.1:8080/` (solo la computadora del equipo).  
**Tipo de trabajo:** modelado preventivo; **no** equivale a demostrar vulnerabilidades explotables.

## Convención
- **Diseño / objetivo:** requisito de seguridad propuesto, todavía no verificado.
- **Observado:** comprobado con método, resultado y captura.
- **Hipótesis:** amenaza plausible, no hallazgo confirmado.
- Evitar capturas con correos reales, contraseñas, cookies, tokens o información confidencial.
