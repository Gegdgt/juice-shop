# Blue Team — Despliegue y observabilidad base para H1

**Responsable:** Sebas Juárez. La defensa completa (SIEM, reglas de detección, WAF bloqueando) pertenece al H3; en H1 se documenta el entorno y su arquitectura.

## Paso 1. Arranque en Windows / PowerShell
Desde la raíz del fork:
```powershell
docker compose -f .\entorno-blue-team\compose.yaml config
docker compose -f .\entorno-blue-team\compose.yaml up -d
docker compose -f .\entorno-blue-team\compose.yaml ps
```

Abrir `http://127.0.0.1:8080/` en el navegador. Documentar código HTTP y captura. Si aparece un error 502/503 al iniciar, revisar logs y volver a cargar cuando el backend termine de arrancar.

## Paso 2. Revisar la ruta de red
`navegador local -> localhost:8080 -> WAF -> red Docker interna -> juice-shop:3000 -> SQLite (dentro del contenedor app)`.

**Comprobaciones:**
- `docker compose ps` solo muestra host `127.0.0.1:8080` como puerto publicado; `3000` puede aparecer como puerto interno sin host.
- Configuración declara `BACKEND=http://juice-shop:3000`.
- `MODSEC_RULE_ENGINE=DetectionOnly`, por lo que el WAF puede registrar/observar, pero **no se debe afirmar bloqueo activo**.

## Paso 3. Consultar logs iniciales
```powershell
docker compose -f .\entorno-blue-team\compose.yaml logs --tail=50 waf
docker compose -f .\entorno-blue-team\compose.yaml logs --tail=50 juice-shop
```

No subir logs completos si contienen tokens, credenciales, identificadores u otros secretos; redactar si es necesario. Los logs de acceso/auditoría podrían estar en archivos internos del contenedor según imagen; **no asumir** que todo evento se imprimirá por `docker logs`.

## Paso 4. Validar riesgos y controles
Revisar `02-PASTA-3-DFD.md` y `03-PASTA-4-STRIDE.md`. Para cada riesgo, indicar si el control corresponde a la app, al WAF o al monitoreo futuro. Un WAF no reemplaza controles de autorización del backend.

## Paso 5. Entregar evidencias
Guardar capturas de Docker Compose, página visible por WAF, configuración `DetectionOnly` y reporte de riesgos revisado. Estado de controles `Implementado / No implementado / Futuro / No comprobado`.

## Diagnóstico
| Problema | Causa posible | Acción |
|---|---|---|
| `docker` no se reconoce | Instalación/PATH o terminal antigua | Abrir Docker Desktop y nuevo PowerShell; ejecutar `docker --version` |
| Docker engine no disponible | WSL2/virtualización o Desktop sin iniciar | Revisar `wsl --status` y el estado de Docker Desktop |
| `localhost:8080` ocupado | Otro servicio en el host | Identificar qué lo ocupa; resolver el conflicto sin exponer puertos públicos |
| 502 en WAF | Backend todavía iniciando o configuración incorrecta | Revisar `docker compose ... logs` y `BACKEND` |
| WAF no bloquea | Estado DetectionOnly de H1 | Es intencional; bloqueo se prueba/tunea en H3 |
