# PASTA IV — Amenazas STRIDE por componente

**Estado:** hipótesis de amenazas para un diseño seguro; ninguna fila demuestra que la vulnerabilidad esté presente. Ajustar después del reconocimiento Red Team.

STRIDE: **S** Suplantación, **T** Manipulación, **R** Repudio, **I** Divulgación de información, **D** Denegación de servicio, **E** Elevación de privilegios.

| Amenaza | Componente / flujo | STRIDE | Escenario de amenaza | Consecuencia | Control o requisito | Caso | Estado |
|---|---|---|---|---|---|---|---|
| T-01 | Navegador / sesión | S | Un tercero reutiliza una sesión/credencial robada | Secuestro de cuenta | RS-01, RS-10 | CA-01 | Hipótesis |
| T-02 | Navegador → WAF, F01 | T | Parámetros enviados por el cliente se alteran antes de llegar a la API | Modificación de acciones o montos | RS-07 | CA-06 | Hipótesis |
| T-03 | WAF, F01-F02 | D | Solicitudes repetitivas agotan capacidad | Degradación del servicio | RS-05 | CA-05 | Hipótesis |
| T-04 | WAF / auditoría | R | No se registran las solicitudes sospechosas | Imposibilidad de atribuir un evento | RS-06 | CA-07 | Hipótesis |
| T-05 | API de autenticación | S | Intentos repetidos consiguen credenciales válidas | Acceso no autorizado | RS-01 | CA-01 | Hipótesis |
| T-06 | API de cesta/pedidos | E | Un usuario cambia un identificador y accede a datos ajenos | Acceso a recursos de otro usuario | RS-02 | CA-02 | Hipótesis |
| T-07 | API de consulta/búsqueda | T | Entrada no validada altera una consulta SQL | Lectura/alteración de datos | RS-03 | CA-03 | Hipótesis |
| T-08 | UI y API que devuelven contenido de usuarios | T | Contenido no escapado ejecuta script en el navegador | XSS, sesión comprometida | RS-04 | CA-04 | Hipótesis |
| T-09 | API que calcula precios / pedidos | T | El cliente envía un precio distinto al autorizado | Integridad de pedido alterada | RS-07 | CA-06 | Hipótesis |
| T-10 | SQLite, F03-F04 | I | Se devuelven registros sin verificar identidad/propietario | Exposición de datos | RS-02 | CA-02 | Hipótesis |
| T-11 | API administrativa | E | Una cuenta corriente invoca operaciones de administración | Privilegios indebidos | RS-09 | CA-08 | Hipótesis |
| T-12 | Logs de app/WAF | I | Se registran claves, cookies o tokens completos | Fuga de secretos en registros | RS-06, RS-10 | CA-07 | Hipótesis |
| T-13 | API / transacciones | R | No se documenta quién cambió un pedido | Falta de trazabilidad | RS-06 | CA-07 | Hipótesis |

## Priorización inicial para el laboratorio
| Riesgo de diseño | Impacto | Exposición estimada | Prioridad | Razón |
|---|---|---|---|---|
| T-06: acceso horizontal a pedidos | Alto | Plausible si la API usa IDs de recursos | Alta | Compromete confidencialidad de múltiples usuarios |
| T-07: inyección en entrada de API | Alto | Plausible en superficie de búsqueda | Alta | Potencial lectura/manipulación de datos |
| T-08: XSS | Medio/alto | Plausible donde se muestra contenido controlado por usuarios | Alta | Afecta navegador, sesión y confianza |
| T-03: saturación | Medio | Depende de límites de tasa | Media | Degrada acceso al laboratorio |
| T-04/T-13: falta de registros | Medio/alto | Depende de instrumentación | Alta | Impide demostrar detección H3 |

**Importante:** la prioridad es una estimación de diseño, no CVSS ni un resultado de explotación. H2 requiere PoCs y clasificación de vulnerabilidades confirmadas.
